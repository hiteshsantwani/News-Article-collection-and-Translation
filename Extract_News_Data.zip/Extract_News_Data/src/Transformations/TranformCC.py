import os.path
import json
from langdetect import detect

path = os.path.abspath(os.path.join(".", os.pardir)) + "/cc_download_articles"
dirs = os.listdir(path)
allowed = []

detect("War doesn't show who's right, just")

nameTranformed = 'TransformedCCData/data'
prev = ''
for i in dirs:
    if i not in allowed and i not in '.DS_Store':
        newpath = path + "/" + i
        for j in os.listdir(newpath):
            with open(newpath + "/" +j, 'r') as f:
                distros_dict = json.load(f)
                if not distros_dict['text'] == prev and detect(str(distros_dict['text'])) == "en":
                    if  'france' in distros_dict['url'] or 'France' in distros_dict['url']:
                        postname = 'France'
                    elif 'United Kingdom' in distros_dict['url'] or 'united kingdom' in distros_dict['url'] or 'UK' in distros_dict['url'] or 'uk' in distros_dict['url']:
                        postname = 'United_Kingdom'
                    elif 'Italy' in distros_dict['url'] or 'italy' in distros_dict['url']:
                        postname = 'Italy'
                    elif 'Germany' in distros_dict['url'] or 'germany' in distros_dict['url']:
                        postname = 'Germany'
                    elif 'Ireland' in distros_dict['url'] or 'ireland' in distros_dict['url']:
                        postname = 'Ireland'
                    elif 'Europe' in distros_dict['url'] or 'europe' in distros_dict['url']:
                        postname = 'Europe'

                    with open(nameTranformed + postname + ' .txt', 'a') as dataFile:
                        dataFile.write(str(distros_dict['text']) + '\n\n\n')
                        prev = distros_dict['text']
